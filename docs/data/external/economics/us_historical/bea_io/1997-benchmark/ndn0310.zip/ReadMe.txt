
README.txt                                     December 11, 2002

Documentation for the 1997 Benchmark Input-Output Accounts: 
Detailed Industry by Industry Total Requirements Table 
and the Total Industry Output Multipliers

Source

 The data in these files were prepared by the Industry
 Economics Division (IED), Bureau of Economic Analysis BE-51,
 U.S. Department of Commerce.  For questions about the 
 tables, please call the IED main number (202-606-5584), or 
 FAX (202-606-5316), or send an E-Mail message to 
 benchmarkio@bea.gov.

Ordering information

  Accession number  --   NDN-0310
  Check payable to  --   Bureau of Economic Analysis          
  Address           --   U.S. Department of Commerce
                         Public Information Office
                         Order Desk, BE-53
                         Bureau of Economic Analysis
                         Washington, DC  20230


Diskette information:  Diskettes for the 1997 benchmark input-output
                       accounts are available for $20 and can be
                       purchased by contacting the address above.

Description of data

  These files contain underlying detailed data from the 1997 benchmark 
  input-output (I-O) accounts published in "Benchmark Input-Output Accounts 
  of the United States, 1997," SURVEY OF CURRENT BUSINESS (December 2002).  
  Copies of this article are available free of charge through the 
  BEA web site, www.bea.doc.gov.  Hard copies of the article can also 
  be purchased for $20.  To purchase BEA products using Visa or 
  Mastercard, please call the BEA Order Desk at 1-800-704-0415.  

  The benchmark I-O methodology, coverage of data, and data definitions 
  are explained in the above SURVEY article. 

  Data files containing the tables are comma delimited ASCII
  files consisting of a row I-O code, a column I-O code, a
  table reference number, and the cell value(s).  Values 
  represent coefficients, as specified in the text files beginning 
  with "F" that are associated with each table.  All cells 
  in the tables are included.  No copyrighted data are found 
  in these files.

      
Description of files

  README.txt             --  Description of the data product

  IO-CodeDetail.xls      --  I-O codes and descriptions, industry and commodity 
                             output following NAICS and I-O definitions
                             (also available in IO-CodeDetail.txt)
  
  NAICS-IO.xls           --  Detailed I-O codes, descriptions and
                             related NAICS codes

  FIO-CodeDetail.txt     --  File layout table for IO-CodeDetail.txt

  MathIO.doc             --  Mathematical derivation of I-O accounts

  Table 8.               --  Industry by Industry Total Requirements,
                             1997 Benchmark
                             (uncompressed file IndbyIndTRDetail.txt)

  FIndbyIndTRDetail.txt  --  File layout table for IndbyIndTRDetail.txt

  IndOut.txt             --  Total Industry Output Multipliers

  FIndOut.txt            --  File layout table for IndOut.txt


 